Requisitos para poder lanzar el proyecto:
- Tener instalado angular, node js, xamp y MySQL
- En el archivo auth-app\auth-backend\.env en el apartado MYSQL_PORT= hay que poner el puerto al que esté conectado el MySQL dentro del equipo, por defecto en el programa está el 3307
- Hay que importar la base de datos desde MyphpAdmin, se adjunta tanto la base de datos oficial como la de prueba que usamos para la demo con algunos datos de prueba introducidos directamente
- En el siguiente repositorio de GitHub está el proyecto con la versión de la demo, que tenía las notificaciones pero no la funcionalidad de mensajería
para clonarlo en local, es necesario tener instalado git.
En VSC hay que instalar la extensión GitHub Pull Requests, en la pantalla de bienvenida elegir la opción de clonar repositorio e introducir el siguiente enlace
https://github.com/Pablo-Montero-PRO2/Buddy_Project.git
y por último elegir la dirección del equipo donde quiere clonarse el repositorio
- Antes de lanzar la aplicación, es necesario instalar el servidor de angular en la carpeta de la aplicación y en la carpeta de auth-backend con el comando npm i para instalar los módulos.
Para iniciar el servidor de angular hay que usar el comando ng serve dentro de la carpeta de la aplicación
En una terminal nueva, dentro de la carpeta de auth-backend hay que lanzar el comando node server.js
Para acceder a la aplicación hay que abrir el enlace del servidor de angular, por defecto el http://localhost:4200/