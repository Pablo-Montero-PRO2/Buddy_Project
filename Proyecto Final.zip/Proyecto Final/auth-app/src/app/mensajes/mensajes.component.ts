import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { concatMap } from 'rxjs/operators';
import { MensajeriaService } from '../services/mensajeria.service';
import { HttpErrorResponse } from '@angular/common/http';
 
@Component({
  selector: 'app-mensajeria',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ], // ✅ Se corrigió el cierre del array
  templateUrl: './mensajes.component.html',
  styleUrls: ['./mensajes.component.css']
})
  export class MensajesComponent implements OnInit {
    mensajeForm!: FormGroup;
    mensajes: any[] = [];
    emails: { [key: number]: string } = {};
    mensajeAbierto: boolean = false;
    errorMessage: string = '';
   
    constructor(
      private fb: FormBuilder,
      private mensajeriaService: MensajeriaService
    ) {}
   
    ngOnInit() {
      this.obtenerMensajes();
      this.mensajeForm = this.fb.group({
        profesorId :['10'],
        alumnoId: ['11'],
        fechaHora: [new Date()],
        email: ['', [ Validators.email]],
        asunto: [''],
        contenido: [''],
        est_mesj:['0']
      });
    }
      obtenerMensajes() {
        this.mensajeriaService.obtenerMensajes().subscribe({
          next: (response: any[]) => {
            console.log('📩 Respuesta de la API:', response);
            // Si la respuesta es un arreglo, asignamos directamente
            this.mensajes = response;  // Asignamos la respuesta directamente, ya que es un array de objetos mensaje
           
            this.mensajes.forEach(mensaje => {
              this.mensajeriaService.obtenerEmail(mensaje.Alumno_usuario_id_usuario).subscribe({
                next: (data) => {
                  console.log('📩 Email obtenido:', data.email);
                  this.emails[mensaje.Alumno_usuario_id_usuario] = data.email; // Guardar email en el objeto mensaje
                },
                error: (error) => {
                  console.error('Error al obtener el correo:', error);
                },
              });
            });
            // Si necesitas hacer algo más con cada mensaje, puedes recorrerlo:
            this.mensajes.forEach(mensaje => {
              console.log('Mensaje:', mensaje);
              // Aquí puedes procesar cada mensaje individualmente si lo deseas
            });
          },
          error: (error: HttpErrorResponse) => {
            console.error('❌ Error al obtener los mensajes:', error);
          }
        });
        }
     
     
    abrirMensaje() {
      console.log('Abrir mensaje función llamada');
      this.mensajeAbierto = true;
    }
   
    cerrarMensaje() {
      this.mensajeAbierto=false;
  }
 
  enviarMensaje() {
    const {profesorId, alumnoId, fechaHora, email, asunto, contenido, est_mesj} = this.mensajeForm.value;
    console.log("Components: ",this.mensajeForm.value);
    this.mensajeriaService.obtenerMensajes().pipe(
      concatMap(() => this.mensajeriaService.enviarMensaje(profesorId, alumnoId, fechaHora, asunto, contenido, est_mesj))
    ).subscribe({
      next: (response) => {
        console.log("Mensaje enviado con éxito:", response);
        this.obtenerMensajes();
       
        const ahora = new Date();
        const fechaHoraFormateada = ahora.toLocaleString('es-ES', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        });
        const nuevoMensaje = {
          profesorId,
          alumnoId,
          fechaHoraFormateada,
          email,
          asunto,
          contenido,
          est_mesj: 0,
          fecha: fechaHoraFormateada,
        };
        this.mensajes.push(nuevoMensaje);
        this.mensajeForm.patchValue({
            email: null,
            contenido: null,
            asunto: null,
            profesorId:this.mensajeForm.value.profesorId,
            alumnoId:this.mensajeForm.value.alumnoId,
            fechaHora:this.mensajeForm.value.fechaHora
        });
        this.cerrarMensaje();
      },
      error: (error: HttpErrorResponse)=>{
          console.error('Error completo:', error);
          }
       
      }
  )};
 
 eliminarMensaje(index: number) {
    const mensaje = this.mensajes[index];
    if (confirm('¿Estás seguro de que quieres eliminar este mensaje?')) {
      this.mensajeriaService.eliminarMensaje(mensaje.id_mensaje).subscribe({
        next: () => {
          console.log('Mensaje eliminado correctamente');
          this.mensajes.splice(index);
        },
        error: (error: HttpErrorResponse) => {
          console.error('Error al eliminar el mensaje', error);
        }
      });
    }
  }
 
}