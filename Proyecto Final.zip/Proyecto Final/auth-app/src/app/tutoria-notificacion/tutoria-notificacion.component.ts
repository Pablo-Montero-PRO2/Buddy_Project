import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tutoria-notificacion',
  standalone: true, // Temporal, hasta que podamos integrarlo en el menú
  imports: [

  ],
  templateUrl: './tutoria-notificacion.component.html',
  styleUrl: './tutoria-notificacion.component.css'
})
export class MensajesNoLeidosComponent {

}
