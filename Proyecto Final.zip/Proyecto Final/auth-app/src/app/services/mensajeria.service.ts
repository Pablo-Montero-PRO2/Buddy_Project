import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
 
 
@Injectable({
  providedIn: 'root'
})
export class MensajeriaService {
  private apiUrl = 'http://localhost:5000/api/mensajeria'; // URL del backend
  constructor(private http: HttpClient) { }
  /* obtenerMensajes(): Observable<any[]> {
      return this.http.get<any[]>(`${this.apiUrl}/obtenerMensajes`);
    }
  }*/
   
    obtenerEmail(id_usuario: number): Observable<any> {
      return this.http.get<{ email: string }>(`${this.apiUrl}/obtenerEmail/${id_usuario}`);
    }    
 
    obtenerMensajes(): Observable<any[]> {
      return this.http.get<{ mensajes: any[] }>(`${this.apiUrl}/obtenerMensajes`).pipe(
        map(response => response.mensajes || [])  // Asegúrate de acceder a la propiedad correcta
      );
    }
   
   
  enviarMensaje(
    profesorId: BigInteger,
    alumnoId: BigInteger,
    fechaHora: Date,
    asunto: string,
    contenido: string,
    est_mesj: number,
  ): Observable<any> {
    const mensaje = { profesorId, alumnoId, fechaHora, asunto, contenido, est_mesj};
    console.log("Service:",profesorId, alumnoId, fechaHora, asunto, contenido, est_mesj);
    return this.http.post(`${this.apiUrl}/enviarMensaje`, mensaje);
  }
  eliminarMensaje(id_mensaje:BigInteger):Observable<void>{
    return this.http.delete<void>(`${this.apiUrl}/eliminarMensaje/${id_mensaje}`);
  }
 
}