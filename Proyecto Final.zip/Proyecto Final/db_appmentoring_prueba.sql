-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3307
-- Tiempo de generación: 02-04-2025 a las 13:19:20
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_appmentoring`
--
CREATE DATABASE IF NOT EXISTS db_appmentoring;
USE db_appmentoring;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad`
--

CREATE TABLE `actividad` (
  `id_actividad` int(11) NOT NULL,
  `Profesor_usuario_id_usuario` int(11) NOT NULL,
  `fecha_publicacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `titulo_act` varchar(256) NOT NULL,
  `tipo_act` varchar(50) NOT NULL,
  `desc_act` varchar(500) NOT NULL,
  `est_act_prof` varchar(50) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `actividad`
--

INSERT INTO `actividad` (`id_actividad`, `Profesor_usuario_id_usuario`, `fecha_publicacion`, `titulo_act`, `tipo_act`, `desc_act`, `est_act_prof`, `createdAt`, `updatedAt`) VALUES
(1, 10, '2025-04-01 18:56:09', 'Presentación de la idea', 'Emprendimiento', 'Crea una presentación para tu proyecto.', 'Creada', '2025-04-01 18:56:09', '2025-04-01 18:56:09'),
(2, 10, '2025-04-01 18:56:09', 'Diseño del logo', 'Creatividad', 'Diseña un logotipo original para tu marca.', 'Creada', '2025-04-01 18:56:09', '2025-04-01 18:56:09'),
(3, 10, '2025-04-01 18:56:09', 'Análisis DAFO', 'Análisis', 'Realiza un DAFO sobre tu idea de negocio.', 'Creada', '2025-04-01 18:56:09', '2025-04-01 18:56:09');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `usuario_id_usuario` int(11) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`usuario_id_usuario`, `createdAt`, `updatedAt`) VALUES
(11, '2025-04-01 18:58:55', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno_has_actividad`
--

CREATE TABLE `alumno_has_actividad` (
  `Alumno_usuario_id_usuario` int(11) NOT NULL,
  `actividad_id_actividad` int(11) NOT NULL,
  `actividad_Profesor_usuario_id_usuario` int(11) NOT NULL,
  `est_act_alu` varchar(50) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `alumno_has_actividad`
--

INSERT INTO `alumno_has_actividad` (`Alumno_usuario_id_usuario`, `actividad_id_actividad`, `actividad_Profesor_usuario_id_usuario`, `est_act_alu`, `createdAt`, `updatedAt`) VALUES
(11, 1, 10, 'En proceso', '2025-04-02 08:54:06', '2025-04-01 19:00:00'),
(11, 2, 10, 'Finalizada', '2025-04-02 08:54:07', '2025-04-01 19:00:00'),
(11, 3, 10, 'Finalizada', '2025-04-02 06:51:04', '2025-04-01 19:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciclo`
--

CREATE TABLE `ciclo` (
  `id_ciclo` int(11) NOT NULL,
  `nom_ciclo` varchar(256) NOT NULL,
  `grado_ciclo` varchar(45) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo`
--

CREATE TABLE `grupo` (
  `id_grupo` int(11) NOT NULL,
  `ciclo_id_ciclo` int(11) NOT NULL,
  `nom_grupo` varchar(45) NOT NULL,
  `curso_grupo` varchar(45) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo_has_actividad`
--

CREATE TABLE `grupo_has_actividad` (
  `grupo_id_grupo` int(11) NOT NULL,
  `actividad_id_actividad` int(11) NOT NULL,
  `fecha_actividad` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `createdAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajeria`
--

CREATE TABLE `mensajeria` (
  `id_mensaje` int(11) NOT NULL,
  `Profesor_usuario_id_usuario` int(11) NOT NULL,
  `Alumno_usuario_id_usuario` int(11) NOT NULL,
  `fecha_hora_mensaje` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `asunto_mensaje` varchar(45) DEFAULT NULL,
  `desc_mensaje` varchar(500) NOT NULL,
  `est_mensaje` tinyint(4) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `mensajeria`
--

INSERT INTO `mensajeria` (`id_mensaje`, `Profesor_usuario_id_usuario`, `Alumno_usuario_id_usuario`, `fecha_hora_mensaje`, `asunto_mensaje`, `desc_mensaje`, `est_mensaje`, `createdAt`, `updatedAt`) VALUES
(2, 10, 11, '2025-04-02 07:36:11', 'Duda sobre la tarea', 'Hola, tengo una duda sobre el ejercicio 3.', 0, '2025-04-02 07:36:11', '2025-04-02 07:36:11'),
(3, 10, 11, '2025-04-02 08:09:39', 'Revisión del proyecto', 'Por favor revisa el documento que subiste al sistema.', 0, '2025-04-02 08:09:39', '2025-04-02 08:09:39'),
(4, 10, 11, '2025-04-02 08:09:53', 'Duda con la tarea', 'Profe, tengo una duda con el ejercicio 5. ¿Puede ayudarme?', 0, '2025-04-02 08:09:53', '2025-04-02 08:09:53'),
(5, 10, 11, '2025-04-02 08:09:53', 'Actividad corregida', 'Ya subí la versión corregida de la actividad. ¿Está bien ahora?', 0, '2025-04-02 08:09:53', '2025-04-02 08:09:53'),
(6, 10, 11, '2025-04-02 08:09:53', 'Gracias', 'Gracias por la ayuda en la última tutoría ?', 0, '2025-04-02 08:09:53', '2025-04-02 08:09:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulo`
--

CREATE TABLE `modulo` (
  `id_modulo` int(11) NOT NULL,
  `ciclo_id_ciclo` int(11) NOT NULL,
  `nom_modulo` varchar(256) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `usuario_id_usuario` int(11) NOT NULL,
  `es_tutor` tinyint(4) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`usuario_id_usuario`, `es_tutor`, `createdAt`, `updatedAt`) VALUES
(10, 1, '2025-04-01 18:50:51', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recurso_actividad`
--

CREATE TABLE `recurso_actividad` (
  `id_recurso` int(11) NOT NULL,
  `actividad_id_actividad` int(11) NOT NULL,
  `desc_recurso` varchar(500) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tutoria`
--

CREATE TABLE `tutoria` (
  `id_tutoria` int(11) NOT NULL,
  `Profesor_usuario_id_usuario` int(11) NOT NULL,
  `Alumno_usuario_id_usuario` int(11) NOT NULL,
  `fecha_tutoria` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `tema_tutoria` varchar(256) NOT NULL,
  `observaciones` varchar(500) DEFAULT NULL,
  `lug_tutoria` varchar(45) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `est_usuario` tinyint(4) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(256) NOT NULL,
  `user` varchar(45) NOT NULL,
  `pass` varchar(256) NOT NULL,
  `email` varchar(45) NOT NULL,
  `telf` varchar(45) DEFAULT NULL,
  `foto` varchar(500) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `est_usuario`, `nombre`, `apellidos`, `user`, `pass`, `email`, `telf`, `foto`, `createdAt`, `updatedAt`) VALUES
(10, 1, 'Luis Armando', 'Dans Rodriguez', 'luis.dans', '$2b$10$ufASI3N0ojAXdhXGCT1T.uDRJzAEt05jOi8UWcWd6Cmo9eGljJupy', 'luis.dans@pro2fp.es', '688555111', 'default.jpg', '2025-04-01 18:50:51', '2025-04-01 18:50:51'),
(11, 1, 'Damián', 'Carrillo Arjones', 'dcarrillo', '$2b$10$AHzVOO9TOBq42NBOT/4/n.9BUHo1eDyN4wPH/jcwQHqDj/DtzU.k6', 'dcarrillo@pro2fp.es', '659462546', 'default.jpg', '2025-04-01 18:58:55', '2025-04-01 18:58:55');

--
-- Disparadores `usuario`
--
DELIMITER $$
CREATE TRIGGER `validar_user_en_email` BEFORE INSERT ON `usuario` FOR EACH ROW BEGIN
    IF NEW.email NOT LIKE CONCAT('%', NEW.user, '%') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El email debe coincidir con el user utilizado';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `validar_user_en_email_update` BEFORE UPDATE ON `usuario` FOR EACH ROW BEGIN
    IF NEW.email NOT LIKE CONCAT('%', NEW.user, '%') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El email debe coincidir con el user utilizado';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_has_grupo`
--

CREATE TABLE `usuario_has_grupo` (
  `usuario_id_usuario` int(11) NOT NULL,
  `grupo_id_grupo` int(11) NOT NULL,
  `vigencia_inicio` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `vigencia_fin` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updatedAt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `actividad`
--
ALTER TABLE `actividad`
  ADD PRIMARY KEY (`id_actividad`,`Profesor_usuario_id_usuario`),
  ADD UNIQUE KEY `id_actividad_UNIQUE` (`id_actividad`),
  ADD KEY `fk_actividad_Profesor1_idx` (`Profesor_usuario_id_usuario`);

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`usuario_id_usuario`),
  ADD UNIQUE KEY `usuario_id_usuario_UNIQUE` (`usuario_id_usuario`);

--
-- Indices de la tabla `alumno_has_actividad`
--
ALTER TABLE `alumno_has_actividad`
  ADD PRIMARY KEY (`Alumno_usuario_id_usuario`,`actividad_id_actividad`,`actividad_Profesor_usuario_id_usuario`),
  ADD KEY `fk_Alumno_has_actividad_actividad1_idx` (`actividad_id_actividad`,`actividad_Profesor_usuario_id_usuario`),
  ADD KEY `fk_Alumno_has_actividad_Alumno1_idx` (`Alumno_usuario_id_usuario`);

--
-- Indices de la tabla `ciclo`
--
ALTER TABLE `ciclo`
  ADD PRIMARY KEY (`id_ciclo`),
  ADD UNIQUE KEY `id_ciclo_UNIQUE` (`id_ciclo`);

--
-- Indices de la tabla `grupo`
--
ALTER TABLE `grupo`
  ADD PRIMARY KEY (`id_grupo`,`ciclo_id_ciclo`),
  ADD UNIQUE KEY `id_grupo_UNIQUE` (`id_grupo`),
  ADD KEY `fk_grupo_ciclo1_idx` (`ciclo_id_ciclo`);

--
-- Indices de la tabla `grupo_has_actividad`
--
ALTER TABLE `grupo_has_actividad`
  ADD PRIMARY KEY (`grupo_id_grupo`,`actividad_id_actividad`,`fecha_actividad`),
  ADD KEY `fk_grupo_has_actividad_actividad1_idx` (`actividad_id_actividad`),
  ADD KEY `fk_grupo_has_actividad_grupo1_idx` (`grupo_id_grupo`);

--
-- Indices de la tabla `mensajeria`
--
ALTER TABLE `mensajeria`
  ADD PRIMARY KEY (`id_mensaje`,`Profesor_usuario_id_usuario`,`Alumno_usuario_id_usuario`),
  ADD UNIQUE KEY `id_mensaje_UNIQUE` (`id_mensaje`),
  ADD KEY `fk_mensajeria_Profesor1_idx` (`Profesor_usuario_id_usuario`),
  ADD KEY `fk_mensajeria_Alumno1_idx` (`Alumno_usuario_id_usuario`);

--
-- Indices de la tabla `modulo`
--
ALTER TABLE `modulo`
  ADD PRIMARY KEY (`id_modulo`,`ciclo_id_ciclo`),
  ADD KEY `fk_modulo_ciclo1_idx` (`ciclo_id_ciclo`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`usuario_id_usuario`),
  ADD UNIQUE KEY `usuario_id_usuario_UNIQUE` (`usuario_id_usuario`);

--
-- Indices de la tabla `recurso_actividad`
--
ALTER TABLE `recurso_actividad`
  ADD PRIMARY KEY (`id_recurso`,`actividad_id_actividad`),
  ADD KEY `fk_recurso_actividad1_idx` (`actividad_id_actividad`);

--
-- Indices de la tabla `tutoria`
--
ALTER TABLE `tutoria`
  ADD PRIMARY KEY (`Profesor_usuario_id_usuario`,`Alumno_usuario_id_usuario`,`id_tutoria`),
  ADD UNIQUE KEY `id_tutoria_UNIQUE` (`id_tutoria`),
  ADD KEY `fk_tutoria_Profesor1_idx` (`Profesor_usuario_id_usuario`),
  ADD KEY `fk_tutoria_Alumno1_idx` (`Alumno_usuario_id_usuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `id_usuario_UNIQUE` (`id_usuario`),
  ADD UNIQUE KEY `user_UNIQUE` (`user`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`);

--
-- Indices de la tabla `usuario_has_grupo`
--
ALTER TABLE `usuario_has_grupo`
  ADD PRIMARY KEY (`usuario_id_usuario`,`grupo_id_grupo`),
  ADD KEY `fk_usuario_has_grupo_grupo1_idx` (`grupo_id_grupo`),
  ADD KEY `fk_usuario_has_grupo_usuario1_idx` (`usuario_id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `actividad`
--
ALTER TABLE `actividad`
  MODIFY `id_actividad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `ciclo`
--
ALTER TABLE `ciclo`
  MODIFY `id_ciclo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `grupo`
--
ALTER TABLE `grupo`
  MODIFY `id_grupo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mensajeria`
--
ALTER TABLE `mensajeria`
  MODIFY `id_mensaje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `recurso_actividad`
--
ALTER TABLE `recurso_actividad`
  MODIFY `id_recurso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tutoria`
--
ALTER TABLE `tutoria`
  MODIFY `id_tutoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `actividad`
--
ALTER TABLE `actividad`
  ADD CONSTRAINT `fk_actividad_Profesor1` FOREIGN KEY (`Profesor_usuario_id_usuario`) REFERENCES `profesor` (`usuario_id_usuario`);

--
-- Filtros para la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD CONSTRAINT `fk_Alumno_usuario1` FOREIGN KEY (`usuario_id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `alumno_has_actividad`
--
ALTER TABLE `alumno_has_actividad`
  ADD CONSTRAINT `fk_Alumno_has_actividad_Alumno1` FOREIGN KEY (`Alumno_usuario_id_usuario`) REFERENCES `alumno` (`usuario_id_usuario`),
  ADD CONSTRAINT `fk_Alumno_has_actividad_actividad1` FOREIGN KEY (`actividad_id_actividad`,`actividad_Profesor_usuario_id_usuario`) REFERENCES `actividad` (`id_actividad`, `Profesor_usuario_id_usuario`);

--
-- Filtros para la tabla `grupo`
--
ALTER TABLE `grupo`
  ADD CONSTRAINT `fk_grupo_ciclo1` FOREIGN KEY (`ciclo_id_ciclo`) REFERENCES `ciclo` (`id_ciclo`);

--
-- Filtros para la tabla `grupo_has_actividad`
--
ALTER TABLE `grupo_has_actividad`
  ADD CONSTRAINT `fk_grupo_has_actividad_actividad1` FOREIGN KEY (`actividad_id_actividad`) REFERENCES `actividad` (`id_actividad`),
  ADD CONSTRAINT `fk_grupo_has_actividad_grupo1` FOREIGN KEY (`grupo_id_grupo`) REFERENCES `grupo` (`id_grupo`);

--
-- Filtros para la tabla `mensajeria`
--
ALTER TABLE `mensajeria`
  ADD CONSTRAINT `fk_mensajeria_Alumno1` FOREIGN KEY (`Alumno_usuario_id_usuario`) REFERENCES `alumno` (`usuario_id_usuario`),
  ADD CONSTRAINT `fk_mensajeria_Profesor1` FOREIGN KEY (`Profesor_usuario_id_usuario`) REFERENCES `profesor` (`usuario_id_usuario`);

--
-- Filtros para la tabla `modulo`
--
ALTER TABLE `modulo`
  ADD CONSTRAINT `fk_modulo_ciclo1` FOREIGN KEY (`ciclo_id_ciclo`) REFERENCES `ciclo` (`id_ciclo`);

--
-- Filtros para la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD CONSTRAINT `fk_Profesor_usuario1` FOREIGN KEY (`usuario_id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `recurso_actividad`
--
ALTER TABLE `recurso_actividad`
  ADD CONSTRAINT `fk_recurso_actividad1` FOREIGN KEY (`actividad_id_actividad`) REFERENCES `actividad` (`id_actividad`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `tutoria`
--
ALTER TABLE `tutoria`
  ADD CONSTRAINT `fk_tutoria_Alumno1` FOREIGN KEY (`Alumno_usuario_id_usuario`) REFERENCES `alumno` (`usuario_id_usuario`),
  ADD CONSTRAINT `fk_tutoria_Profesor1` FOREIGN KEY (`Profesor_usuario_id_usuario`) REFERENCES `profesor` (`usuario_id_usuario`);

--
-- Filtros para la tabla `usuario_has_grupo`
--
ALTER TABLE `usuario_has_grupo`
  ADD CONSTRAINT `fk_usuario_has_grupo_grupo1` FOREIGN KEY (`grupo_id_grupo`) REFERENCES `grupo` (`id_grupo`),
  ADD CONSTRAINT `fk_usuario_has_grupo_usuario1` FOREIGN KEY (`usuario_id_usuario`) REFERENCES `usuario` (`id_usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
